const signInButton = document.querySelector('#signInButton');
const signUpButton = document.querySelector('#signUpButton');
const overlay_container = document.querySelector('.container1 .overlay-container1');
const overlay = document.querySelector('.container1 .overlay-container1 .overlay');
const signInForm = document.querySelector('.container1 .sign-in-form');
const signUpForm = document.querySelector('.container1 .sign-Up-form');

signInButton.addEventListener('click', () => {
		overlay_container.style.transform = 'translateX(100%)';
		overlay.style.transform = 'translateX(-50%)';
		
		
});
